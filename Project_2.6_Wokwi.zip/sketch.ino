const int ldrPin = A0;
const int relayPin = 7;
const int ledPin = 8;
const int buzzerPin = 9;

void setup() {
  pinMode(relayPin, OUTPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  Serial.begin(9600);
}
void loop() {
  int lightLevel = analogRead(ldrPin);


  if (lightLevel < 500) {
    digitalWrite(relayPin, HIGH);
    digitalWrite(ledPin, HIGH);
    tone(buzzerPin, 800);
  } 
 
  else {
    digitalWrite(relayPin, LOW);
    digitalWrite(ledPin, LOW);
    noTone(buzzerPin);
  }

  Serial.print("Light Level: ");
  Serial.println(lightLevel);
  delay(100);
}